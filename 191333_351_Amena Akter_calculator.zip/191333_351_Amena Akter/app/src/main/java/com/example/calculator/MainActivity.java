package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edtNumber;
    Button btnDelete, btnAccept, btnPercent, btn9, btn8, btn7, btn6, btn5, btn4, btn3, btn2, btn1, btnZero,
            btnPlus, btnMinus, btnMultiplication, btnDivision, btnDot, btnEqual;
    TextView tvShow;

    float answer=0;
    float num1,num2;
    boolean plus,minus,multiplication,division,addition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnZero=findViewById(R.id.btnZero);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        btn5=findViewById(R.id.btn5);
        btn6=findViewById(R.id.btn6);
        btn7=findViewById(R.id.btn7);
        btn8=findViewById(R.id.btn8);
        btn9=findViewById(R.id.btn9);
        btnPercent=findViewById(R.id.btnPercent);
        btnAccept=findViewById(R.id.btnAccept);
        btnEqual = findViewById(R.id.btnEqual);
        btnPlus = findViewById(R.id.btnPlus);
        tvShow = findViewById(R.id.tvShow);
        edtNumber = findViewById(R.id.edtNumber);
        btnDelete=findViewById(R.id.btnDelete);
        btnMinus=findViewById(R.id.btnMinus);
        btnMultiplication=findViewById(R.id.btnMultiplication);
        btnDivision=findViewById(R.id.btnDivision);
        btnDot=findViewById(R.id.btnDot);


        btnZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"0");
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"9");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"3");
            }
        });
        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer += Integer.parseInt(edtNumber.getText()+"+");
                edtNumber.setText("");

            }
        });
        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer += Integer.parseInt(edtNumber.getText()+"=");

            }
        });
        btnMultiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"*");
            }
        });
        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+"-");
            }
        });
        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(edtNumber.getText()+".");
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtNumber.setText(" ");
            }
        });
        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNumber==null){
                    edtNumber.setText("");
                }
                else {
                    num1=Float.parseFloat(edtNumber.getText()+" ");
                    plus=true;
                    edtNumber.setText("");
                }

            }
        });
        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNumber==null){
                    edtNumber.setText("");
                }
                else {
                    num1=Float.parseFloat(edtNumber.getText()+" ");
                    plus=true;
                    edtNumber.setText("");
                }

            }
        });
        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNumber==null){
                    edtNumber.setText("");
                }
                else {
                    num1=Float.parseFloat(edtNumber.getText()+" ");
                    minus=true;
                    edtNumber.setText(" ");
                }

            }
        });
        btnMultiplication.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtNumber==null){
                    edtNumber.setText("");
                }
                else {
                    num1=Float.parseFloat(edtNumber.getText()+" ");
                    multiplication=true;
                    edtNumber.setText("");
                }

            }
        });
        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                num2=Float.parseFloat(edtNumber.getText()+" ");

                if(plus==true){
                    edtNumber.setText(num1+num2+"");
                    plus=false;
                }
                if(minus==true){
                    edtNumber.setText(num1-num2+"");
                    minus=false;
                }
                if(multiplication==true){
                    edtNumber.setText(num1*num2+"");
                    multiplication=false;
                }

            }
        });




    }
}